package kidsense.kadho.com.kidsense_offline_demo;

public class Configs
{
    public static boolean IS_USE_LOCAL_VAD = true;
}
